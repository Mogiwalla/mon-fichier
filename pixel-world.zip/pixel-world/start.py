from func import *
    
######## INIT DATAS ###########
window = pygame.display.set_mode((w, h))
render_distance = 25

clock = pygame.time.Clock()
font = pygame.font.SysFont("arial", 17)
credits = font.render("Minot Alexi -TD06", True, (0,0,0), (75, 190, 245))
texture_pack_name = "classic"
textures = load_textures(texture_pack_name, square_size)
qwerty = True
states = Stack("title screen") # LIFO data
running = True
skip_first_click = True
world_name = ""
square_selected_id = GRASS
world = player_line = cam = None
min_select_line   = max_select_line   = 0
min_select_column = max_select_column = 0
aera = pygame.Rect(0,0,0,0)

colors_of_squares = {GRASS: (15, 130, 10),
                     DIRT : (140, 105, 65),
                     STONE: (170, 170, 170),
                     TRUNK: (100, 50, 25),
                     LEAF: (135, 175, 10),
                     CABLE: (255,0,0),
                     CHARGER: (0,255,0),
                     POWERED_CABLE: (0,155,0),
                     AND: (0,0,155),
                     POWERED_AND: (0,0,255),
                     OR: (155,0,155),
                     POWERED_OR: (255,0,255),
                     NOT: (155,155,0),
                     POWERED_NOT: (255,255,0),
                     XOR: (0,155,155),
                     POWERED_XOR: (0,255,255),
                     BRIDGE: (0,0,0),
                     BRIDGE_OFF_ON: (75,75,75),
                     BRIDGE_ON_OFF: (175,175,175),
                     BRIDGE_ON_ON: (255,255,255)}

##### CREATE BUTTONS #######
new_world_button  = pygame.Rect(w/2-w/8, 6*w/20, w/4, h/15)
load_world_button = pygame.Rect(w/2-w/8, new_world_button.y+new_world_button.h*1.25, w/4, h/15)
textures_button   = pygame.Rect(w/2-w/8, load_world_button.y+load_world_button.h*1.25, w/4, h/15)
switch_keyboard   = pygame.Rect(w/2-w/8, textures_button.y+textures_button.h*1.25, w/4, h/15)
quit_button       = pygame.Rect(w/2-w/8, switch_keyboard.y+switch_keyboard.h*1.25, w/4, h/15)
back_button       = pygame.Rect(w/20, h/16, h/15, h/15)

##### CREATE TEXTS #######
new_world_text     = font.render("create new world", True, (0,0,0))
load_world_text    = font.render("load a world", True, (0,0,0))
textures_text      = font.render("load a texture pack", True, (0,0,0))
quit_text          = font.render("quit", True, (0,0,0))
name_world_text    = font.render("name of the world:", True, (255,255,255))
error_create_world = font.render("your are limited to 10 worlds", True, (255,255,255))
version_text       = font.render(version, True, (255,255,255))
qwerty_text        = font.render("pass to azerty", True, (0,0,0))
azerty_text        = font.render("pass to qwerty", True, (0,0,0))

##### CREATE BUTTON TEXTS POS #####
new_world_text_pos = (new_world_button.x+(new_world_button.w-new_world_text.get_width())/2,
                      new_world_button.y+(new_world_button.h-new_world_text.get_height())/2)
load_world_text_pos = (load_world_button.x+(load_world_button.w-load_world_text.get_width())/2,
                      load_world_button.y+(load_world_button.h-load_world_text.get_height())/2)
textures_text_pos = (textures_button.x+(load_world_button.w-textures_text.get_width())/2,
                     textures_button.y+(textures_button.h-textures_text.get_height())/2)
quit_text_pos = (quit_button.x+(quit_button.w-quit_text.get_width())/2,
                 quit_button.y+(quit_button.h-quit_text.get_height())/2)
azerty_text_pos = (switch_keyboard.x+(switch_keyboard.w-azerty_text.get_width())/2,
                   switch_keyboard.y+(switch_keyboard.h-azerty_text.get_height())/2)
qwerty_text_pos = (switch_keyboard.x+(switch_keyboard.w-qwerty_text.get_width())/2,
                   switch_keyboard.y+(switch_keyboard.h-qwerty_text.get_height())/2)
error_create_world_pos = (new_world_button.x+(textures_button.w-error_create_world.get_width())/2,
                          new_world_button.y-new_world_button.h/2)
name_world_text_pos = (new_world_button.x+(new_world_button.w-new_world_text.get_width())/2,
                       new_world_button.y+new_world_button.h*1.25)
world_name_texture_pos = (new_world_button.x+(new_world_button.w-new_world_text.get_width())/2,
                          new_world_button.y+new_world_button.h*1.35+name_world_text.get_height())

while running:
    state = states.get()

    ####### INPUTS EVENTS ########
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            if state == "game":
                save(world_name, world, cam)

        elif state == "title screen":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if new_world_button.collidepoint(event.pos):
                        if len(get_worlds()) < 10:
                            world_name = ""
                            states.append("naming the world")
                    elif load_world_button.collidepoint(event.pos):
                        states.append("load a world")
                    elif textures_button.collidepoint(event.pos):
                        states.append("load a texture pack")
                    elif switch_keyboard.collidepoint(event.pos):
                        qwerty = not qwerty
                    elif quit_button.collidepoint(event.pos):
                        running = False
        elif state == "naming the world":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if new_world_button.collidepoint(event.pos):
                        pygame.display.set_caption(title_window + world_name)
                        world, cam_line = create_world()
                        cam = Player(cam_line-5, square_size, 500)
                        states.popright()
                        states.append("game")
                    elif back_button.collidepoint(event.pos):
                        states.popright()
            elif event.type == pygame.KEYDOWN:
                if event.key not in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    if event.key == pygame.K_BACKSPACE:
                        world_name[:-1]
                    elif len(world_name) < 15:
                        world_name += event.unicode
                else:
                    pygame.display.set_caption(title_window + world_name)
                    world, cam_line = create_world()
                    cam = Player(cam_line-5, square_size, 500)
                    states.popright()
                    states.append("game")
        elif state == "load a world":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if back_button.collidepoint(event.pos):
                        states.popright()

                    worlds = get_worlds()
                    for i in range(len(worlds)):
                        button = pygame.Rect(w/2-w/8, 5*h/20+i*h/10, w/4, h/15)
                        delete_button = pygame.Rect(button.x+1.1*button.w, button.y, button.h, button.h)
                        if button.collidepoint(event.pos):
                            world_name, world, cam = load(worlds[i])
                            pygame.display.set_caption(title_window+world_name)
                            states.popright()
                            states.append("game")
                        elif delete_button.collidepoint(event.pos):
                            delete_world(worlds, i)
        elif state == "load a texture pack":
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == LEFT_CLICK:
                    if back_button.collidepoint(event.pos):
                        states.popright()

                list_packs = get_textures_packs()
                for i in range(len(list_packs)):
                    button = pygame.Rect(w/2-w/8, 5*h/20+i*h/10, w/4, h/15)
                    if button.collidepoint(event.pos):
                        textures = load_textures(list_packs[i], square_size)
                        actual_pack = list_packs[i]
                        states.popright()
        elif state == "game":
            if event.type == pygame.MOUSEWHEEL:
                if event.y > 0:
                    square_selected_id += 1
                    if square_selected_id > LAST_ID:
                        square_selected_id = GRASS
                else:
                    square_selected_id -= 1
                    if square_selected_id < GRASS:
                        square_selected_id = LAST_ID

            elif event.type == pygame.MOUSEBUTTONDOWN:
                cursor_x, cursor_y = event.pos
                min_select_column = (cursor_x + cam.x)//square_size
                min_select_line   = (cursor_y + cam.y)//square_size

            elif event.type == pygame.MOUSEMOTION:
                cursor_x, cursor_y = event.pos
                cursor_column = (cursor_x + cam.x)//square_size
                cursor_line = (cursor_y + cam.y)//square_size

                if min_select_column*square_size != 0:
                    if cursor_column < 0:
                        cursor_column = 0

                    if cursor_line < 0:
                        cursor_line = 0
                    elif cursor_line > 99:
                        cursor_line = 99

                    if cursor_column < min_select_column:
                        aera.x = cursor_column*square_size - cam.x
                        aera.w = min_select_column*square_size - aera.x + square_size - cam.x
                    else:
                        aera.x = min_select_column*square_size - cam.x
                        aera.w = cursor_column*square_size - aera.x + square_size - cam.x

                    if cursor_line < min_select_line:
                        aera.y = cursor_line*square_size - cam.y
                        aera.h = min_select_line*square_size - aera.y + square_size - cam.y
                    else:
                        aera.y = min_select_line*square_size - cam.y
                        aera.h = cursor_line*square_size - aera.y + square_size - cam.y
                else:
                    aera = pygame.Rect(0,0,0,0)

            elif event.type == pygame.MOUSEBUTTONUP:
                if skip_first_click:
                    skip_first_click = False
                else:
                    aera = pygame.Rect(0,0,0,0)
                    cursor_x, cursor_y = event.pos
                    max_select_column = (cursor_x + cam.x)//square_size
                    max_select_line   = (cursor_y + cam.y)//square_size

                    if max_select_column < 0:
                        max_select_column = 0

                    if max_select_line < 0:
                        max_select_line = 0
                    elif max_select_line > 99:
                        max_select_line = 99

                    if max_select_line < min_select_line:
                        max_select_line, min_select_line = min_select_line, max_select_line

                    if max_select_column < min_select_column:
                        max_select_column, min_select_column = min_select_column, max_select_column

                    square = VOID if event.button == LEFT_CLICK else square_selected_id

                    for line in range(min_select_line, max_select_line+1):
                        for column in range(min_select_column, max_select_column+1):
                            place_square(world, line, column, square)

                    min_select_line   = max_select_line   = 0
                    min_select_column = max_select_column = 0
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    states.popright()
                    save(world_name, world, cam)
                    skip_first_click = True

    #### RUNNING GAME #####
    if state == "game":
        delta_time = clock.tick() / 1000

        cam.update(delta_time, square_size, world, render_distance, qwerty)
        
        pos = [font.render(f"{cam.x=}", True, (0,0,0)),
                font.render(f"{cam.y=}", True, (0,0,0)),
                font.render(f"{cam.column=}", True, (0,0,0)),
                font.render(f"{cam.line=}", True, (0,0,0))]
        
        column_started = cam.x//square_size
        column_finish = cam.x//square_size + render_distance
        line_started = cam.y//square_size
        line_finish = cam.y//square_size + render_distance

        if line_finish > 100:
            line_finish = 100

        execute_elecity(world, column_started, column_finish, line_started, line_finish)

        #### DRAWIING ####
        window.fill((75, 190, 245))

        # draw the world
        for column in range(column_started, column_finish):
            for line in range(line_started, line_finish):
                current_id = world[line][column]
                if current_id != VOID:
                    square_pos = (column*square_size - cam.x, line*square_size - cam.y)
                    current_square = pygame.Rect(square_pos, (square_size, square_size))  
                    if textures[current_id] != None:
                        window.blit(textures[current_id], current_square)
                    else:
                        current_color = colors_of_squares[current_id]
                        pygame.draw.rect(window, current_color, current_square)

        gfxdraw.box(window, aera, (10,10,10,100))

        for i in range(len(pos)):
            window.blit(pos[i], (10, 15+i*20))

        square_selected = pygame.Rect(w - 20 - square_size*1.5, 20, square_size*1.5, square_size*1.5)  

        if textures[square_selected_id] != None:
            texture = pygame.transform.scale(textures[square_selected_id], (square_size*1.75, square_size*1.75))
            window.blit(texture, square_selected)
        else:
            color_selected  = colors_of_squares[square_selected_id]
            pygame.draw.rect(window, color_selected, square_selected)
    
    else:
        window.fill((0,0,0))

        window.blit(version_text, (w*0.05, h*0.85))

        if textures["title"] != None:
            title = pygame.Rect(w//2-textures["title"].get_width()//2,
                                h//50, 0,0)
            window.blit(textures["title"], title)

    if state == "title screen":
        if textures["button"] == None:
            pygame.draw.rect(window, (200,200,200), new_world_button)
            pygame.draw.rect(window, (200,200,200), load_world_button)
            pygame.draw.rect(window, (200,200,200), textures_button)
            pygame.draw.rect(window, (200,200,200), switch_keyboard)
            pygame.draw.rect(window, (200,200,200), quit_button)
        else:
            window.blit(textures["button"], new_world_button)
            window.blit(textures["button"], load_world_button)
            window.blit(textures["button"], textures_button)
            window.blit(textures["button"], switch_keyboard)
            window.blit(textures["button"], quit_button)

        window.blit(new_world_text, new_world_text_pos)
        window.blit(load_world_text, load_world_text_pos)
        window.blit(textures_text, textures_text_pos)
        window.blit(quit_text, quit_text_pos)
        if qwerty:
            window.blit(qwerty_text, qwerty_text_pos)
        else:
            window.blit(azerty_text, azerty_text_pos)

    elif state == "naming the world":
        pygame.draw.rect(window, (200,200,200), back_button)
        if textures["button"] == None:
            pygame.draw.rect(window, (200,200,200), new_world_button)
        else:
            window.blit(textures["button"], new_world_button)

        world_name_texture = font.render(" "+world_name+" ", True, (0,0,0), (220,220,220))
        window.blit(world_name_texture, world_name_texture_pos)
        window.blit(error_create_world, error_create_world_pos)
        window.blit(new_world_text, new_world_text_pos)

    elif state == "load a world":
        pygame.draw.rect(window, (200,200,200), back_button)

        worlds = get_worlds()
        for i in range(len(worlds)):
            button = pygame.Rect(w/2-w/8, 5*h/20+i*h/10, w/4, h/15)
            delete_button = pygame.Rect(button.x+1.1*button.w, button.y, button.h, button.h)
            text = font.render(worlds[i][:-4], True, (0,0,0))        
            text_pos = (button.x+(button.w-text.get_width())/2,
                        button.y+(button.h-text.get_height())/2)
            if textures["button"] == None:
                pygame.draw.rect(window, (200,200,200), button)
            else:
                window.blit(textures["button"], button)
            pygame.draw.rect(window, (200,200,200), delete_button)
            window.blit(text, text_pos)

    elif state == "load a texture pack":
        pygame.draw.rect(window, (200,200,200), back_button)

        list_packs = get_textures_packs()
        for i in range(len(list_packs)):
            button = pygame.Rect(w/2-w/8, 5*h/20+i*h/10, w/4, h/15)
            text = font.render(list_packs[i], True, (0,0,0))        
            text_pos = (button.x+(button.w-text.get_width())/2,
                        button.y+(button.h-text.get_height())/2)
            if textures["button"] == None:
                pygame.draw.rect(window, (200,200,200), button)
            else:
                window.blit(textures["button"], button)
            window.blit(text, text_pos)

    pygame.display.flip()

save(world_name, world, cam)
pygame.quit()

if have_maj():
    update()