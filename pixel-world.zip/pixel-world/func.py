from random import randint
import pygame
from pygame import gfxdraw
import pickle
import os
import urllib.request
import zipfile
import shutil
from collections import deque

pygame.init()

version = "4.0.0"
URL_VERSION = "https://github.com/Mogiwalla/pixel-world/version"
URL_GAME    = "https://github.com/Mogiwalla/pixel-world/pixel-world.zip"

w = 800
h = 600
square_size = w//20
title_window = "pixel world: "
LEFT_CLICK = 1
RIGHT_CLICK = 3

# const contain elements of world
VOID = 0
GRASS = 1
DIRT = 2
STONE = 3
TRUNK = 4
LEAF = 5

CABLE = 6
POWERED_CABLE = -6
CHARGER = 7

OR = 8
POWERED_OR = -8

AND = 9
POWERED_AND = -9

NOT = 10
POWERED_NOT = -10

XOR = 11
POWERED_XOR = -11

BRIDGE = 12
BRIDGE_ON_OFF = -112 # vertical is on, horizontal is off
BRIDGE_OFF_ON = -113
BRIDGE_ON_ON  = -114

LAST_ID = BRIDGE

SOURCES = (CHARGER, POWERED_CABLE)
POWERED_DOORS = (POWERED_AND, POWERED_OR, POWERED_XOR, POWERED_NOT)
BRIDGES = (BRIDGE, BRIDGE_OFF_ON, BRIDGE_ON_OFF, BRIDGE_ON_ON)
POWERED_BRIDGES_H = (BRIDGE_ON_ON, BRIDGE_OFF_ON)
POWERED_BRIDGES_V = (BRIDGE_ON_ON, BRIDGE_ON_OFF)

def have_maj():
    try:
        with urllib.request.urlopen(URL_VERSION, timeout=10):
            with open("version", "w") as file:
                new_version = file.readline()
            return new_version != version
    except:
        print("page not found")
        return False

def update():
    urllib.request.urlretrieve(URL_GAME, "download.zip")
    os.makedirs("download", exist_ok=True)
    with zipfile.ZipFile("download.zip", "r") as file:
        file.extractall("download")
    os.remove( "download.zip")
    shutil.move("download/textures/classic", "textures")
    shutil.move("download/func.py", "func.py")
    shutil.move("download/start.py", "start.py")
    os.removedirs("download")

def place_square(world, line, column, square_id):
    if line >= 0 and line < 100 and column >= 0:
        world[line][column] = square_id

def power_from_left(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line][column-1]
        return current_square in SOURCES or (
               current_square in POWERED_DOORS or(
               current_square in POWERED_BRIDGES_H))
    return False

def power_from_right(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line][column+1]
        return current_square in SOURCES or(
               current_square in POWERED_BRIDGES_H)
    return False

def power_from_top(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line-1][column]
        return current_square in SOURCES or(
               current_square in POWERED_BRIDGES_V)
    return False

def power_from_bottom(world, line, column):
    if -1 < line < 100 and -1 < column:
        current_square = world[line+1][column]
        return current_square in SOURCES or(
               current_square in POWERED_BRIDGES_V)
    return False

def execute_elecity(world, column_started, column_finish, line_started, line_finish):
    for line in range(line_started, line_finish):
        for column in range(column_started, column_finish):
            if world[line][column] == POWERED_CABLE:
                world[line][column] = CABLE
            elif world[line][column] == POWERED_OR:
                world[line][column] = OR
            elif world[line][column] == POWERED_AND:
                world[line][column] = AND
            elif world[line][column] in BRIDGES:
                world[line][column] = BRIDGE

    screen = []
    for line in range(line_started, line_finish):
        for column in range(column_started, column_finish):
            screen.append((line, column))

    wait = deque(screen) # FIFO data

    while wait: # while not wait is empty
        line, column = wait.popleft()
        square = world[line][column]
        new_square = square

        left  = power_from_left(world, line, column)
        right = power_from_right(world, line, column)
        top = power_from_top(world, line, column)
        bottom = power_from_bottom(world, line, column)

        if square == CABLE:
            if left or right or top or bottom:
                new_square = POWERED_CABLE
        elif square in BRIDGES:
            horizontal = left or right
            vertical = top or bottom

            if horizontal and vertical:
                new_square = BRIDGE_ON_ON
            elif horizontal:
                new_square = BRIDGE_OFF_ON
            elif vertical:
                new_square = BRIDGE_ON_OFF
        elif square == OR:
            if top or bottom:
                new_square = POWERED_OR
        elif square == AND:
            if top and bottom:
                new_square = POWERED_AND

        if new_square != square:
            world[line][column] = new_square
            neighbours = ((line, column-1), (line, column+1),
                          (line-1, column), (line+1, column))
            for n_line, n_column in neighbours:
                if n_line < 100 and n_line >= 0 and n_column >= 0:
                    if (n_line, n_column) not in wait:
                        wait.append((n_line, n_column))

    for line, column in screen:
        square = world[line][column]
        if square in (NOT, POWERED_NOT):
            new_square = NOT if power_from_left(world, line, column) else POWERED_NOT
            world[line][column] = new_square
        elif square in (XOR, POWERED_XOR):
            on = power_from_top(world, line, column) != power_from_bottom(world, line, column)
            new_square = POWERED_XOR if on else XOR
            world[line][column] = new_square

def get_worlds():
    """
    return names of files in worlds directory
    """
    return os.listdir("worlds")

def get_textures_packs():
    """
    return names of directorys in textures directory
    """
    return os.listdir("textures")

def delete_world(worlds, i):
    os.remove("worlds/"+worlds[i])
    worlds.pop(i)

def load_texture(dir, list_textures, img, resize):
    if img in list_textures:
        texture = pygame.image.load(dir+"/"+img)
        return pygame.transform.scale(texture, (resize, resize))
    else:
        return None
    

def load_textures(pack, square_size):
    dir = "textures/"+pack
    list_textures = os.listdir(dir)
    button = load_texture(dir, list_textures, "button.png", square_size)
    if button != None:
        button = pygame.transform.scale(button, (w/4, (2*h+h/6)/15))
    return {
        GRASS: load_texture(dir, list_textures, "grass.png", square_size),
        DIRT: load_texture(dir, list_textures, "dirt.png", square_size),
        STONE: load_texture(dir, list_textures, "stone.png", square_size),
        TRUNK: load_texture(dir, list_textures, "trunk.png", square_size),
        LEAF: load_texture(dir, list_textures, "leaf.png", square_size),
        CABLE: load_texture(dir, list_textures, "cable.png", square_size),
        POWERED_CABLE: load_texture(dir, list_textures, "powered cable.png", square_size),
        OR: load_texture(dir, list_textures, "or.png", square_size),
        AND: load_texture(dir, list_textures, "and.png", square_size),
        NOT: load_texture(dir, list_textures, "not.png", square_size),
        POWERED_OR: load_texture(dir, list_textures, "powered or.png", square_size),
        POWERED_AND: load_texture(dir, list_textures, "powered and.png", square_size),
        POWERED_NOT: load_texture(dir, list_textures, "powered not.png", square_size),
        XOR: load_texture(dir, list_textures, "xor.png", square_size),
        POWERED_XOR: load_texture(dir, list_textures, "powered xor.png", square_size),
        BRIDGE: load_texture(dir, list_textures, "bridge.png", square_size),
        BRIDGE_OFF_ON: load_texture(dir, list_textures, "bridge off on.png", square_size),
        BRIDGE_ON_OFF: load_texture(dir, list_textures, "bridge on off.png", square_size),
        BRIDGE_ON_ON: load_texture(dir, list_textures, "bridge on on.png", square_size),
        CHARGER: load_texture(dir, list_textures, "charger.png", square_size),
        "title": load_texture(dir, list_textures, "title.png", 4*square_size),
        "button": button
    }

def save(name, world, cam):
    """
    save the world name, the world and cam to a pickle file
    """
    with open(f"worlds/{name}.pkl", "wb") as file:
        pickle.dump((name, world, cam), file)

def load(name):
    """
    return the world name, the world and cam to a pickle file
    """
    with open(f"worlds/{name}", "rb") as file:
        datas = pickle.load(file)
    return datas

def create_tree(column, world):
    """
    create and place a new tree to the world
    """
    # recover line of grass
    line = 0
    for l in range(100): # the world have 100 squares of heights
        if world[l][column] == GRASS:
            line = l
            break

    len_trunk = randint(3, 5)
    for i in range(1, len_trunk):
        world[line-i][column] = TRUNK

    for c in range(column-2, column+3):
        if world[line-len_trunk][c] == VOID:
            world[line-len_trunk][c] = LEAF

    for c in range(column-1, column+2):
        if world[line-len_trunk-1][c] == VOID:
            world[line-len_trunk-1][c] = LEAF


def create_world():
    """
    return a list of list of int and line above the line of the first grass.
    int is a element of world
    """

    first_grass = None
    last_tree = 0
    shift_tree = randint(2, 8)

    # the world have 100 squares of heights
    world = [[] for _ in range(100)]

    # the world have 100 squares of weight in start
    line = 50
    depth = 5
    for column in range(100):
        line = randint(line-3, line+3)
        while line > 85:
            line = randint(line-4,line-2)

        depth = randint(depth-1, depth+1)
        if depth < 1:
            depth += 1
        
        # place voids of this column
        for i in range(line-1):
            world[i].append(VOID)

        # place grass of this column
        world[line-1].append(GRASS)
        if first_grass == None:
            first_grass = line-1

        # place dirts of this column
        for i in range(depth):
            world[line+i].append(DIRT)

        # place stones of this column
        for i in range(line+depth, 100):
            world[i].append(STONE)

        if column == last_tree + shift_tree + 5:
            create_tree(column-3, world)
            shift_tree = randint(2, 8)
            last_tree = column-3

    return world, first_grass-1

def generate(world, size):
    """
    generate a continuation of the world
    """

    # recover depth and line of dirts
    depth = 0
    l = 0
    while world[l][-1] != STONE:
        if world[l][-1] == DIRT:
            depth += 1
        l += 1
    line = l - depth

    last_tree = len(world[0])
    shift_tree =randint(2, 8)

    for _ in range(size):
        line = randint(line-3, line+3)
        while line > 85:
            line = randint(line-4,line-2)

        depth = randint(depth-1, depth+1)
        if depth < 1:
            depth += 1
        
        # place voids of this column
        for i in range(line-1):
            world[i].append(VOID)

        # place grass of this column
        world[line-1].append(GRASS)

        # place dirts of this column
        for i in range(depth):
            world[line+i].append(DIRT)

        # place stones of this column
        for i in range(line+depth, 100):
            world[i].append(STONE)

        column = len(world[0])
        if column == last_tree + shift_tree + 4:
            create_tree(column-4, world)
            shift_tree = randint(2, 8)
            last_tree = column-3

class Player:
    def __init__(self, line, square_size, speed):
        self.line = line
        self.column = 0
        self.x = 0
        self.y = line*square_size
        self.speed = speed

    # move and update the position
    def update(self, delta_time, square_size, world, render_distance, qwerty):
        keys = pygame.key.get_pressed()

        move = int(self.speed*delta_time)

        if qwerty:
            if keys[pygame.K_w]:
                self.y -= move

            if keys[pygame.K_a]:
                self.x -= move
        else:
            if keys[pygame.K_z]:
                self.y -= move

            if keys[pygame.K_q]:
                self.x -= move

        if keys[pygame.K_s]:
            self.y += move

        if keys[pygame.K_d]:
            self.x += move

        self.line = self.y//square_size
        self.column = self.x//square_size

        if self.column < 0:
            self.x += move

        if self.line < 0:
            self.y += move
        elif self.line > 84:
            self.y -= move

        if self.column + render_distance//2 > len(world[0]):
            generate(world, 50)

class Stack:
    def __init__(self, *args):
        self.list = [arg for arg in args]

    def popright(self):
        self.list.pop()

    def get(self):
        return self.list[-1]

    def append(self, arg):
        self.list.append(arg)

    def is_empty(self):
        return len(self.list) == 0